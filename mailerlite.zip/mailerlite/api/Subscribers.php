<?php

//Subscribers.php

class Subscribers
{
    private $connect = '';

    function __construct()
    {
        $host = "localhost";
        $dbname = "mailerlite";
        $user = "root";
        $password = "";
        $this->database_connection($host, $dbname, $user, $password);
    }

    function database_connection($host, $dbname, $user, $password)
    {
        $this->connect = new PDO(
            "mysql:host=$host;dbname=$dbname",
            $user,
            $password
        );
    }

    function all_subscribers()
    {
        $query = "SELECT * FROM subscribers ORDER BY id";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                $data[] = $row;
            }
            return $data;
        }
    }

    function insert()
    {
        //check valid email and other fields not to be empty
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) and
            !empty($_POST["name"])
        ) {
            //check whether a the email domain is active
            $domain_parts = explode('@', $_POST['email']);
            $domain = $domain_parts[1];
            if ((checkdnsrr($domain))) {
                $form_data = array(
                    ':name'   => htmlspecialchars(strip_tags($_POST["name"])),
                    ':email'  => htmlspecialchars(strip_tags($_POST["email"])),
                    ':status' => htmlspecialchars(strip_tags($_POST["status"]))
                );
                $query = "
			INSERT INTO subscribers 
			(name, email, status) VALUES 
			(:name, :email, :status)
			";
                $statement = $this->connect->prepare($query);
                if ($statement->execute($form_data)) {
                    $data[] = array(
                        'success' => '1'
                    );
                } else {
                    $data[] = array(
                        'success' => '0'
                    );
                }
            } else {
                $data[] = array(
                    'success' => '0'
                );
            }
        } else {
            $data[] = array(
                'success' => '0'
            );
        }
        return $data;
    }

    function single_subscriber($id)
    {
        $query = "SELECT * FROM subscribers WHERE id='".htmlspecialchars(
                strip_tags($id)
            )."'";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            foreach ($statement->fetchAll() as $row) {
                $data['name'] = $row['name'];
                $data['email'] = $row['email'];
                $data['status'] = $row['status'];
            }
            return $data;
        }
    }

    function update()
    {
        if (isset($_POST["name"])) {
            $form_data = array(
                ':name'   => htmlspecialchars(strip_tags($_POST['name'])),
                ':email'  => htmlspecialchars(strip_tags($_POST['email'])),
                ':status' => htmlspecialchars(strip_tags($_POST['status'])),
                ':id'     => htmlspecialchars(strip_tags($_POST['id']))
            );
            $query = "
			UPDATE subscribers 
			SET name = :name, email = :email, status = :status 
			WHERE id = :id ";
            $statement = $this->connect->prepare($query);
            if ($statement->execute($form_data)) {
                $data[] = array(
                    'success' => '1'
                );
            } else {
                $data[] = array(
                    'success' => '0'
                );
            }
        } else {
            $data[] = array(
                'success' => '0'
            );
        }
        return $data;
    }

    function delete($id)
    {
        $query = "DELETE FROM subscribers WHERE id = '".htmlspecialchars(
                strip_tags($id)
            )."'";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            $data[] = array(
                'success' => '1'
            );
        } else {
            $data[] = array(
                'success' => '0'
            );
        }
        return $data;
    }

    //subscriber fields
    function subcriber_fields($id)
    {
        $query = "SELECT * FROM fields where subscriber_id=".htmlspecialchars(
                strip_tags($id)
            )." ORDER BY id";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                $data[] = $row;
            }
            return $data;
        }
    }

    function single_field($id)
    {
        $query = "SELECT * FROM fields WHERE id='".htmlspecialchars(
                strip_tags($id)
            )."'";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            foreach ($statement->fetchAll() as $row) {
                $data['title'] = $row['title'];
                $data['f_type'] = $row['f_type'];
                $data['subscriber_id'] = $row['subscriber_id'];
            }
            return $data;
        }
    }

    function insert_field()
    {
        if (isset($_POST["title"])) {
            $form_data = array(
                ':title'         => htmlspecialchars(
                    strip_tags($_POST["title"])
                ),
                ':f_type'        => htmlspecialchars(
                    strip_tags($_POST["f_type"])
                ),
                ':subscriber_id' => htmlspecialchars(
                    strip_tags($_POST["subscriber_id"])
                )
            );
            $query = "
			INSERT INTO fields 
			 (title, f_type, subscriber_id) VALUES 
			 (:title, :f_type, :subscriber_id)
			";
            $statement = $this->connect->prepare($query);
            if ($statement->execute($form_data)) {
                $data[] = array(
                    'success' => '1'
                );
            } else {
                $data[] = array(
                    'success' => '0'
                );
            }
        } else {
            $data[] = array(
                'success' => '0'
            );
        }
        return $data;
    }

    function update_field()
    {
        if (isset($_POST["title"])) {
            $form_data = array(
                ':title'         => htmlspecialchars(
                    strip_tags($_POST['title'])
                ),
                ':f_type'        => htmlspecialchars(
                    strip_tags($_POST['f_type'])
                ),
                ':subscriber_id' => htmlspecialchars(
                    strip_tags($_POST['subscriber_id'])
                ),
                ':id'            => htmlspecialchars(strip_tags($_POST['id']))
            );
            $query = "
			UPDATE fields 
			SET title = :title, f_type = :f_type, subscriber_id = :subscriber_id 
			WHERE id = :id ";
            $statement = $this->connect->prepare($query);
            if ($statement->execute($form_data)) {
                $data[] = array(
                    'success' => '1'
                );
            } else {
                $data[] = array(
                    'success' => '0'
                );
            }
        } else {
            $data[] = array(
                'success' => '0'
            );
        }
        return $data;
    }

    function delete_field($id)
    {
        $query = "DELETE FROM fields WHERE id = '".htmlspecialchars(
                strip_tags($id)
            )."'";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            $data[] = array(
                'success' => '1'
            );
        } else {
            $data[] = array(
                'success' => '0'
            );
        }
        return $data;
    }
}

?>