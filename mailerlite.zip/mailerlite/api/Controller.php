<?php

//Api Controller

include 'Subscribers.php';

$subscriber_object = new Subscribers();

if ($_GET["action"] == 'all_subscribers') {
    $data = $subscriber_object->all_subscribers();
}

if ($_GET["action"] == 'single_subscriber') {
    $data = $subscriber_object->single_subscriber($_GET["id"]);
}

if ($_GET["action"] == 'insert') {
    $data = $subscriber_object->insert();
}

if ($_GET["action"] == 'update') {
    $data = $subscriber_object->update();
}

if ($_GET["action"] == 'delete') {
    $data = $subscriber_object->delete($_GET["id"]);
}

//subcriber fields calls
if ($_GET["action"] == 'sub_fields') {
    $data = $subscriber_object->subcriber_fields($_GET["id"]);
}

if ($_GET["action"] == 'insert_field') {
    $data = $subscriber_object->insert_field();
}

if ($_GET["action"] == 'update_field') {
    $data = $subscriber_object->update_field();
}

if ($_GET["action"] == 'delete_field') {
    $data = $subscriber_object->delete_field($_GET["id"]);
}

if ($_GET["action"] == 'single_field') {
    $data = $subscriber_object->single_field($_GET["id"]);
}

echo json_encode($data);

?>