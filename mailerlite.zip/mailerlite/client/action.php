<?php

//action.php

if (isset($_POST["action"])) {
    // Get Site Address Dynamically
    $site_addr = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'
            ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'];
    //Must end with /
    $site_addr = rtrim($site_addr, "/\\").'/';
    $mapi_url = $site_addr."mailerlite/api/controller.php";  //change this url as per api folder

    if ($_POST["action"] == 'all_subscribers') {
        $api_url = $mapi_url
            ."?action=all_subscribers";  //get all subscriber
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        $result = json_decode($response);
        $output = '';
        if (!empty($result)) {
            foreach ($result as $row) {
                $output .= '<tr>
                    <td>'.$row->name.'</td>
                    <td>'.$row->email.'</td>
                    <td>'.$row->status.'</td>
                    <td>
                        <button type="button" name="edit" class="btn btn-warning btn-xs edit" id="'
                    .$row->id.'">Edit</button>
                        <button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'
                    .$row->id.'">Delete</button>
                        <a class="btn btn-primary btn-xs " href="fields.php?id='
                    .$row->id.'">Subscriber Fields</a>
                      
                    </td>
                </tr> ';
            }
        } else {
            $output .= '<tr>
                <td colspan="4" class="text-center">No Data Found</td>
            </tr>';
        }

        echo $output;
    }
    if ($_POST["action"] == 'single_subscriber') {
        $id = $_POST["id"];
        $api_url = $mapi_url."?action=single_subscriber&id=".$id
            ."";        // to a single subscriber
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        echo $response;
    }
    if ($_POST["action"] == 'insert') {
        $form_data = array(
            'name'   => $_POST['name'],
            'email'  => $_POST['email'],
            'status' => $_POST['status']
        );
        $api_url = $mapi_url
            ."?action=insert";  //to insert a subsriber
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_POST, true);
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        curl_close($client);
        $result = json_decode($response, true);
        foreach ($result as $keys => $values) {
            if ($result[$keys]['success'] == '1') {
                echo 'insert';
            } else {
                echo 'error';
            }
        }
    }
    if ($_POST["action"] == 'update') {
        $form_data = array(
            'name'   => $_POST['name'],
            'email'  => $_POST['email'],
            'status' => $_POST['status'],
            'id'     => $_POST['hidden_id']
        );
        $api_url = $mapi_url
            ."?action=update";  // to update a subscriber
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_POST, true);
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        curl_close($client);
        $result = json_decode($response, true);
        foreach ($result as $keys => $values) {
            if ($result[$keys]['success'] == '1') {
                echo 'update';
            } else {
                echo 'error';
            }
        }
    }
    if ($_POST["action"] == 'delete') {
        $id = $_POST['id'];
        $api_url = $mapi_url."?action=delete&id=".$id
            .""; //to delete a subscriber
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        echo $response;
    }

    //fields part
    if ($_POST["action"] == 'list_subscribers') {
        $api_url = $mapi_url
            ."?action=all_subscribers";  // list subscribers to usd for fields
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        $result = json_decode($response);
        $output = '';
        if (count($result) > 0) {
            foreach ($result as $row) {
                $select = $_POST["id"]==$row->id? "selected='selected'":'';
                $output .= '<option '.$select.' value="'.$row->id.'">'.$row->name
                    .'</option>';
            }
        } else {
            $output .= '<option value="">No record found</option>';
        }

        echo $output;
    }
    if ($_POST["action"] == 'sub_fields') {
        $id = $_POST["id"];
        $api_url = $mapi_url."?action=sub_fields&id=".$id
            ."";  //get a subscriber's fields records
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        //echo $response;
        $result = json_decode($response);
        $output = '';
        if (!empty($result)) {
            foreach ($result as $row) {
                $output .= ' <tr>
                                <td>'.$row->title.'</td>
                                <td>'.$row->f_type.'</td>
                                <td>
                                    <button type="button" name="edit" class="btn btn-warning btn-xs edit" id="'
                    .$row->id.'">Edit</button>
                                    <button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'
                    .$row->id.'">Delete</button>
                                </td>
                            </tr>';
            }
        } else {
            $output .= '<tr>
                            <td colspan="4" class="text-center">No Data Found</td>
                        </tr>';
        }
        echo $output;
    }
    if ($_POST["action"] == 'single_field') {
        $id = $_POST["id"];
        $api_url = $mapi_url."?action=single_field&id=".$id
            ."";  // to get a single field
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        echo $response;
    }
    if ($_POST["action"] == 'insert_field') {
        $form_data = array(
            'title'         => $_POST['title'],
            'f_type'        => $_POST['f_type'],
            'subscriber_id' => $_POST['subscriber_id']
        );
        $api_url = $mapi_url
            ."?action=insert_field";  //to insert a field
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_POST, true);
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        curl_close($client);
        $result = json_decode($response, true);
        foreach ($result as $keys => $values) {
            if ($result[$keys]['success'] == '1') {
                echo 'insert_field';
            } else {
                echo 'error';
            }
        }
    }
    if ($_POST["action"] == 'update_field') {
        $form_data = array(
            'title'         => $_POST['title'],
            'f_type'        => $_POST['f_type'],
            'subscriber_id' => $_POST['subscriber_id'],
            'id'            => $_POST['hidden_id']
        );
        $api_url = $mapi_url
            ."?action=update_field";  //to update a field
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_POST, true);
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        curl_close($client);
        $result = json_decode($response, true);
        foreach ($result as $keys => $values) {
            if ($result[$keys]['success'] == '1') {
                echo 'update_field';
            } else {
                echo 'error';
            }
        }
    }
    if ($_POST["action"] == 'delete_field') {
        $id = $_POST['id'];
        $api_url = $mapi_url."?action=delete_field&id=".$id
            .""; // to delete a field
        $client = curl_init($api_url);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        echo $response;
    }
}


?>