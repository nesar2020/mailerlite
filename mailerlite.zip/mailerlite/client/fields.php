<!DOCTYPE html>
<html lang="en">
<head>
    <title>MailerLite API client</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../assets/css/main.css"/>

</head>
<body>
<div style="width:300px; display: none;position: absolute;z-index:999;margin-left:50px;"
     data-show-duration="5000" id="flashmsgholder"
     class="alert alert-success alert-dismissable animated bounce">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <span id="flash_msg"></span>
</div>
<div class="container">
    <div class="container">
        <div class="row">
            <!-- subscriber data -->
            <div class="col-md-6">
                <input type="hidden" id="sub_id" value="<?php
                echo $_GET['id']; ?>"/>
                <br/>
                <a href="index.php" class="btn btn-success">Back</a>
                <h3 class="text-left hello">MailerLite API client</h3>
                <hr/>
                <div>
                    <h4>Subscriber Details</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Subscriber Name</th>
                            <th>Email</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody id="sub_details"></tbody>
                    </table>
                </div>
            </div>

            <!-- field data -->
            <div class="col-md-6">
                <h4 class="text-left subtitle">Subscriber Fields Management</h4>
                <hr/>
                <div class="text-left" style="margin-bottom:5px;">
                    <button type="button" name="add_button" id="add_button"
                            class="btn btn-primary">Add New Field
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Field Type</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody id="sub_fields"></tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>


</div>
</body>
</html>

<div id="apicrudModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="api_crud_form">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                    <h4 class="modal-title">Add New Field</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Field Title</label>
                        <input type="text" name="title" id="title" required
                               class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label for="f_type">Field Type</label>
                        <select name="f_type" id="f_type"
                                class="form-control">
                            <option value="date">date</option>
                            <option value="number">number</option>
                            <option value="string">string</option>
                            <option value="boolean">boolean</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="subscriber_id">Subscriber</label>
                        <select name="subscriber_id"
                                id="subscriber_id" class="form-control">
                        </select>
                    </div>


                </div>
                <div class="modal-footer">
                    <input type="hidden" name="hidden_id" id="hidden_id"/>
                    <input type="hidden" name="action" id="action"
                           value="insert_field"/>
                    <input type="submit" name="button_action" id="button_action"
                           class="btn btn-info" value="Add Field"/>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../assets/js/jquery-3.3.1.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var sub_id = $('#sub_id').val();
        getSubscriber(sub_id);
        getFields(sub_id);
        list_subsribers();


        function getSubscriber(subid) {
            var action = 'single_subscriber';
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {id: subid, action: action},
                success: function (data) {
                    var subscriber_data = JSON.parse(data);
                    var row_txt = '<tr><td>' + subscriber_data.name + "</td>";
                    row_txt += '<td>' + subscriber_data.email + "</td>";
                    row_txt += '<td>' + subscriber_data.status + "</td></tr>";
                    $('#sub_details').html(row_txt);
                }
            })
        }

        function getFields(subid) {
            var action = 'sub_fields';
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {id: subid, action: action},
                success: function (data) {
                    $('#sub_fields').html(data);
                }
            })
        }

        function list_subsribers() {
            var action = 'list_subscribers';
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {action: action, id: sub_id},
                success: function (data) {
                    $('#subscriber_id').html(data);
                }
            })
        }

        $('#add_button').click(function () {
            $('#action').val('insert_field');
            $('#button_action').val('Add Field');
            $('.modal-title').text('Add New Field');
            $('#apicrudModal').modal('show');
        });

        $('#api_crud_form').on('submit', function (event) {
            event.preventDefault();
            if ($('#title').val() === '') {
                alert("Enter Title");
            } else if ($('#f_type').val() === '') {
                alert("Enter Field Type");
            } else if ($('#subscriber_id').val() == '') {
                alert("Select Subcriber");
            } else {
                var form_data = $(this).serialize();
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: form_data,
                    success: function (data) {
                        getSubscriber(sub_id);
                        getFields(sub_id);
                        list_subsribers();
                        $('#api_crud_form')[0].reset();
                        $('#apicrudModal').modal('hide');
                        if (data === 'insert_field') {
                            hideFlashMsg("Field inserted successfully");
                        }
                        if (data === 'update_field') {
                            hideFlashMsg("Field updated successfully");
                        }
                    }
                });
            }
        });

        //get single field values for editing
        $(document).on('click', '.edit', function () {
            var id = $(this).attr('id');
            var action = 'single_field';
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {id: id, action: action},
                dataType: "json",
                success: function (data) {
                    $('#hidden_id').val(id);
                    $('#title').val(data.title);
                    $('#f_type').val(data.f_type);
                    $('#subscriber_id').val(data.subscriber_id);
                    $('#action').val('update_field');
                    $('#button_action').val('Update Field');
                    $('.modal-title').text('Edit Field');
                    $('#apicrudModal').modal('show');
                }
            })
        });

        $(document).on('click', '.delete', function () {
            var id = $(this).attr("id");
            var action = 'delete_field';
            if (confirm("Are you sure you want to remove this field?")) {
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: {id: id, action: action},
                    success: function (data) {
                        getSubscriber(sub_id);
                        getFields(sub_id);
                        list_subsribers();
                        hideFlashMsg("Field deleted successfully");
                    }
                });
            }
        });

        function hideFlashMsg(msg) {
            var elem = $('#flashmsgholder');
            var duration = elem.attr("data-show-duration");
            $('#flash_msg').text(msg);
            elem.show();
            if (duration > 0) {
                window.setTimeout(function () {
                    elem.fadeOut();
                }, duration)
            }
        }

    });
</script>