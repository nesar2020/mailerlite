<!DOCTYPE html>
<html lang="en">
<head>
    <title>MailerLite API client</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="../assets/css/main.css"/>

</head>
<body>
<div class="container">
    <div style="width:300px; display: none;position: absolute;"
         data-show-duration="5000" id="flashmsgholder"
         class="alert alert-success alert-dismissable animated bounce">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <span id="flash_msg"></span>
    </div>
    <h3 class="text-center hello">MailerLite API client</h3>
    <h4 class="text-center subtitle">Subscriber Management</h4>
    <br/>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="text-left">
                        <button type="button" name="add_button" id="add_button"
                                class="btn btn-primary">Add New Subscriber
                        </button>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="text-right">
                        <a class="btn btn-info" href="../ReadMe.html">API
                            Documentation
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <br/>


    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>


</body>
</html>

<div id="apicrudModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="api_crud_form">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                    <h4 class="modal-title">Add New Subscriber</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Subscriber Name</label>
                        <input type="text" name="name" id="name" required
                               class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" required
                               class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="active">active</option>
                            <option value="unsubscribed">unsubscribed</option>
                            <option value="junk">junk</option>
                            <option value="bounced">bounced</option>
                            <option value="unconfirmed">unconfirmed</option>
                        </select>

                    </div>

                </div>
                <div class="modal-footer">
                    <input type="hidden" name="hidden_id" id="hidden_id"/>
                    <input type="hidden" name="action" id="action"
                           value="insert"/>
                    <input type="submit" name="button_action" id="button_action"
                           class="btn btn-info" value="Insert"/>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../assets/js/jquery-3.3.1.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {

        all_subscribers();

        function all_subscribers() {
            var action = 'all_subscribers';
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {action: action},
                success: function (data) {
                    $('tbody').html(data);
                }
            })
        }

        $('#add_button').click(function () {
            $('#action').val('insert');
            $('#button_action').val('Insert');
            $('.modal-title').text('Add Subscriber');
            $('#apicrudModal').modal('show');
        });

        $('#api_crud_form').on('submit', function (event) {
            event.preventDefault();
            if ($('#name').val() === '') {
                alert("Enter Name");
            } else if ($('#email').val() === '') {
                alert("Enter Email");
            } else if ($('#status').val() === '') {
                alert("Enter Status");
            } else {
                var form_data = $(this).serialize();
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: form_data,
                    success: function (data) {
                        all_subscribers();
                        $('#api_crud_form')[0].reset();
                        $('#apicrudModal').modal('hide');
                        if (data === 'insert') {
                            hideFlashMsg("Subscriber inserted successfully");
                        }
                        if (data === 'update') {
                            hideFlashMsg("Subscriber Updated successfully");
                        }
                    }
                }).fail(function() {
                    alert('Subscriber insertion failed!!!');
                });
            }
        });

        $(document).on('click', '.edit', function () {
            var id = $(this).attr('id');
            var action = 'single_subscriber';
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {id: id, action: action},
                dataType: "json",
                success: function (data) {
                    $('#hidden_id').val(id);
                    $('#name').val(data.name);
                    $('#email').val(data.email);
                    $('#status').val(data.status);
                    $('#action').val('update');
                    $('#button_action').val('Update');
                    $('.modal-title').text('Edit Subscriber');
                    $('#apicrudModal').modal('show');
                }
            })
        });

        $(document).on('click', '.delete', function () {
            var id = $(this).attr("id");
            var action = 'delete';
            if (confirm("Are you sure you want to remove this record?")) {
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: {id: id, action: action},
                    success: function (data) {
                        all_subscribers();
                        hideFlashMsg("Subscriber Deleted !!!");
                    }
                });
            }
        });

        function hideFlashMsg(msg) {
            var elem = $('#flashmsgholder');
            var duration = elem.attr("data-show-duration");
            $('#flash_msg').text(msg);
            elem.show();
            if (duration > 0) {
                window.setTimeout(function () {
                    elem.fadeOut();
                }, duration)
            }
        }

    });
</script>